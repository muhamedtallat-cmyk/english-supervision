from flask import Flask, render_template, request, redirect, url_for, session, flash, Response, abort
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, csv, io
from pathlib import Path
from functools import wraps
from datetime import datetime
import os, re, secrets, shutil

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get('DATABASE_PATH', str(BASE / 'data.db'))).expanduser()
app = Flask(__name__)
app.secret_key = os.environ.get('APP_SECRET_KEY') or 'DEV_ONLY_CHANGE_THIS_SECRET_KEY'
if app.secret_key == 'DEV_ONLY_CHANGE_THIS_SECRET_KEY' and os.environ.get('FLASK_DEBUG','0') != '1':
    # Production must provide a real secret.
    raise RuntimeError('APP_SECRET_KEY must be set outside debug mode.')
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','0')=='1', SESSION_COOKIE_NAME='english_supervision_session', PERMANENT_SESSION_LIFETIME=3600)

@app.after_request
def security_headers(response):
    response.headers.setdefault('X-Content-Type-Options', 'nosniff')
    response.headers.setdefault('X-Frame-Options', 'DENY')
    response.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
    response.headers.setdefault('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
    if request.is_secure:
        response.headers.setdefault('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
    return response

QUOTAS = {
 'ابتدائي': {'معلم مساعد':24,'معلم':24,'معلم أول':22,'معلم أول أ':20,'معلم خبير':18,'كبير معلمين':16},
 'إعدادي': {'معلم مساعد':21,'معلم':21,'معلم أول':21,'معلم أول أ':19,'معلم خبير':17,'كبير معلمين':15},
 'ثانوي': {'معلم مساعد':18,'معلم':18,'معلم أول':17,'معلم أول أ':16,'معلم خبير':16,'كبير معلمين':14},
}
LESSONS={'KG1':8,'KG2':8,'ابتدائي1':5,'ابتدائي2':5,'ابتدائي3':5,'ابتدائي4':4,'ابتدائي5':4,'ابتدائي6':4,'إعدادي1':5,'إعدادي2':6,'إعدادي3':6,'ثانوي1':4,'ثانوي2':6,'ثانوي3':6}
JOB_TITLES=list(next(iter(QUOTAS.values())).keys())
STAGES=['ابتدائي','إعدادي','ثانوي']
DAYS=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس']

def db():
 DB.parent.mkdir(parents=True, exist_ok=True)
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init_db():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','supervisor')),phone TEXT,active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS schools(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,name TEXT NOT NULL,stage TEXT NOT NULL,supervisor_id INTEGER REFERENCES users(id),address TEXT,status TEXT DEFAULT 'نشطة',kg1 INTEGER DEFAULT 0,kg2 INTEGER DEFAULT 0,g1 INTEGER DEFAULT 0,g2 INTEGER DEFAULT 0,g3 INTEGER DEFAULT 0,g4 INTEGER DEFAULT 0,g5 INTEGER DEFAULT 0,g6 INTEGER DEFAULT 0,p1 INTEGER DEFAULT 0,p2 INTEGER DEFAULT 0,p3 INTEGER DEFAULT 0,s1 INTEGER DEFAULT 0,s2 INTEGER DEFAULT 0,s3 INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,job_title TEXT NOT NULL,appointment_date TEXT,official_appointment_date TEXT,national_id TEXT,birth_date TEXT,code TEXT UNIQUE,original_school_id INTEGER REFERENCES schools(id),delegated_school_id INTEGER REFERENCES schools(id),classes_count INTEGER DEFAULT 0,lessons_count INTEGER DEFAULT 0,residence TEXT,phone TEXT,transferred_activity TEXT,stage TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS routes(id INTEGER PRIMARY KEY AUTOINCREMENT,supervisor_id INTEGER NOT NULL REFERENCES users(id),day TEXT NOT NULL,school_id INTEGER NOT NULL REFERENCES schools(id),visit_order INTEGER DEFAULT 1,visit_time TEXT,notes TEXT);
 CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,entity TEXT NOT NULL,entity_id INTEGER,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
 ''')
 if c.execute('SELECT COUNT(*) FROM users').fetchone()[0]==0:
  a=c.execute("INSERT INTO users(name,username,password,role) VALUES(?,?,?,?)",('المدير الرئيسي','admin',generate_password_hash('Admin@123'),'admin')).lastrowid
  s=c.execute("INSERT INTO users(name,username,password,role) VALUES(?,?,?,?)",('موجه تجريبي','supervisor1',generate_password_hash('Sup@123'),'supervisor')).lastrowid
  c.execute("INSERT INTO schools(code,name,stage,supervisor_id,address,g1,g2,g3,g4,g5,g6) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('SCH-001','مدرسة تجريبية 1','ابتدائي',s,'المنيا',2,2,2,2,2,2))
  c.execute("INSERT INTO schools(code,name,stage,supervisor_id,address,p1,p2,p3) VALUES(?,?,?,?,?,?,?,?)",('SCH-002','مدرسة تجريبية 2','إعدادي',s,'المنيا',3,3,2))
  c.commit()
 c.close()



def csrf_token():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_urlsafe(32)
    return session['csrf_token']

@app.context_processor
def security_globals():
    return {'csrf_token': csrf_token()}

@app.before_request
def csrf_protect():
    if request.method == 'POST' and request.endpoint not in {'static'}:
        token = request.form.get('_csrf')
        if not token or not secrets.compare_digest(token, session.get('csrf_token','')):
            abort(400, description='طلب غير صالح أو انتهت صلاحية النموذج.')

def clean_digits(value):
    return ''.join(ch for ch in (value or '') if ch.isdigit())

def validate_teacher_data(d, teacher_id=None):
    errors=[]
    if not (d.get('name') or '').strip(): errors.append('اسم المعلم مطلوب.')
    nid=(d.get('national_id') or '').strip()
    if nid:
        c=db(); row=c.execute('SELECT id FROM teachers WHERE national_id=? AND id!=?',(nid, teacher_id or 0)).fetchone(); c.close()
        if row: errors.append('الرقم القومي مسجل بالفعل لمعلم آخر.')
    if d.get('national_id') and not re.fullmatch(r'\d{14}', d.get('national_id')): errors.append('الرقم القومي يجب أن يتكون من 14 رقمًا.')
    if d.get('phone') and not re.fullmatch(r'01\d{9}', d.get('phone')): errors.append('رقم الهاتف يجب أن يتكون من 11 رقمًا ويبدأ بـ 01.')
    for key,label in [('classes_count','عدد الفصول'),('lessons_count','عدد الحصص')]:
        if d.get(key):
            try:
                if int(d[key]) < 0: errors.append(f'{label} لا يمكن أن يكون سالبًا.')
            except ValueError: errors.append(f'{label} يجب أن يكون رقمًا صحيحًا.')
    if d.get('job_title') not in JOB_TITLES: errors.append('المسمى الوظيفي غير صحيح.')
    if d.get('stage') not in STAGES: errors.append('المرحلة غير صحيحة.')
    return errors


def current(): return session.get('user')
def login_required(f):
 @wraps(f)
 def w(*a,**k):
  if not current(): return redirect(url_for('login'))
  return f(*a,**k)
 return w
def admin_required(f):
 @wraps(f)
 def w(*a,**k):
  if not current(): return redirect(url_for('login'))
  if current()['role']!='admin': abort(403)
  return f(*a,**k)
 return w

def allowed_school(school_id):
 if current()['role']=='admin': return True
 c=db(); r=c.execute('SELECT 1 FROM schools WHERE id=? AND supervisor_id=?',(school_id,current()['id'])).fetchone(); c.close(); return bool(r)

def audit(action,entity,entity_id=None,details=''):
 c=db(); c.execute('INSERT INTO audit_log(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)',(current()['id'] if current() else None,action,entity,entity_id,details)); c.commit(); c.close()

def required_lessons(s):
 vals={'KG1':s['kg1'],'KG2':s['kg2'],'ابتدائي1':s['g1'],'ابتدائي2':s['g2'],'ابتدائي3':s['g3'],'ابتدائي4':s['g4'],'ابتدائي5':s['g5'],'ابتدائي6':s['g6'],'إعدادي1':s['p1'],'إعدادي2':s['p2'],'إعدادي3':s['p3'],'ثانوي1':s['s1'],'ثانوي2':s['s2'],'ثانوي3':s['s3']}
 return sum(int(vals[k] or 0)*LESSONS[k] for k in vals)

def teacher_quota(t): return QUOTAS.get(t['stage'],{}).get(t['job_title'],0)
def school_stats(s):
 c=db(); ts=c.execute('SELECT * FROM teachers WHERE delegated_school_id=? OR original_school_id=?',(s['id'],s['id'])).fetchall(); c.close()
 available=sum(teacher_quota(t) for t in ts); req=required_lessons(s); diff=available-req
 return {'required':req,'available':available,'shortage':max(0,-diff),'surplus':max(0,diff),'teachers':len(ts)}

@app.context_processor
def globals(): return {'current_user':current(),'job_titles':JOB_TITLES,'stages':STAGES,'days':DAYS}

# Initialize schema on import so Gunicorn/WSGI starts with a ready database.
init_db()

@app.route('/health')
def health():
    try:
        c=db(); c.execute('SELECT 1').fetchone(); c.close()
        return {'status':'ok','service':'english-supervision'}, 200
    except Exception:
        return {'status':'error','service':'english-supervision'}, 503

def error_page(code, title, message):
    return Response(f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{code} - منصة إدارة ومتابعة معلمي اللغة الإنجليزية</title><style>body{{font-family:Arial,sans-serif;background:#f5f7fb;margin:0;display:grid;place-items:center;min-height:100vh;color:#1f2937}}main{{max-width:620px;margin:24px;padding:36px;background:#fff;border-radius:18px;box-shadow:0 10px 30px rgba(0,0,0,.08);text-align:center}}h1{{font-size:56px;margin:0 0 8px}}h2{{margin:0 0 14px}}p{{line-height:1.8;color:#64748b}}a{{display:inline-block;margin-top:14px;padding:10px 18px;border-radius:10px;background:#1f4b7a;color:#fff;text-decoration:none}}</style></head><body><main><h1>{code}</h1><h2>{title}</h2><p>{message}</p><a href="/">العودة إلى الصفحة الرئيسية</a></main></body></html>''', status=code, mimetype='text/html')

@app.errorhandler(400)
def bad_request(error): return error_page(400, 'طلب غير صالح', getattr(error, 'description', 'تعذر معالجة الطلب.'))
@app.errorhandler(403)
def forbidden(error): return error_page(403, 'غير مسموح', 'ليس لديك الصلاحية للوصول إلى هذه الصفحة.')
@app.errorhandler(404)
def not_found(error): return error_page(404, 'الصفحة غير موجودة', 'الرابط المطلوب غير موجود أو تم نقله.')
@app.errorhandler(500)
def server_error(error): return error_page(500, 'حدث خطأ غير متوقع', 'تعذر إكمال الطلب حاليًا. حاول مرة أخرى لاحقًا.')

@app.route('/')
def home(): return redirect(url_for('dashboard') if current() else url_for('login'))
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  c=db(); u=c.execute('SELECT * FROM users WHERE username=? AND active=1',(request.form['username'],)).fetchone(); c.close()
  if u and check_password_hash(u['password'],request.form.get('password','')):
   session.clear()
   session.permanent = True
   session['csrf_token'] = secrets.token_urlsafe(32)
   session['user']={'id':u['id'],'name':u['name'],'role':u['role']}
   audit('تسجيل دخول','نظام')
   return redirect(url_for('dashboard'))
  attempted_username=(request.form.get('username') or '').strip()[:120]
  audit('محاولة دخول فاشلة','نظام',None,attempted_username)
  flash('اسم المستخدم أو كلمة المرور غير صحيحة','danger')
 return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
 c=db();
 if current()['role']=='admin': schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id ORDER BY s.name').fetchall(); teachers=c.execute('SELECT * FROM teachers').fetchall()
 else: schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE s.supervisor_id=? ORDER BY s.name',(current()['id'],)).fetchall(); teachers=c.execute('SELECT t.* FROM teachers t JOIN schools s ON s.id=COALESCE(t.delegated_school_id,t.original_school_id) WHERE s.supervisor_id=?',(current()['id'],)).fetchall()
 c.close(); st={'teachers':len(teachers),'required':0,'available':0,'shortage':0,'surplus':0}
 for s in schools:
  x=school_stats(s); st['required']+=x['required']; st['available']+=x['available']; st['shortage']+=x['shortage']; st['surplus']+=x['surplus']
 return render_template('dashboard.html',schools=schools,stats=st,school_stats=school_stats)

@app.route('/teachers')
@login_required
def teachers():
 q=request.args.get('q','').strip(); c=db(); sql='SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id WHERE 1=1'; args=[]
 if current()['role']!='admin': sql+=' AND (os.supervisor_id=? OR ds.supervisor_id=?)'; args += [current()['id'],current()['id']]
 if q: sql+=' AND (t.name LIKE ? OR t.national_id LIKE ? OR t.code LIKE ?)'; args += [f'%{q}%']*3
 rows=c.execute(sql+' ORDER BY t.name',args).fetchall(); c.close(); return render_template('teachers.html',teachers=rows,q=q,teacher_quota=teacher_quota)

@app.route('/teacher/new',methods=['GET','POST'])
@login_required
def teacher_new():
 if request.method=='POST':
  d=request.form
  errors=validate_teacher_data(d, None)
  if errors:
   for e in errors: flash(e,'danger')
   c=db(); schools=c.execute('SELECT * FROM schools ORDER BY name').fetchall() if current()['role']=='admin' else c.execute('SELECT * FROM schools WHERE supervisor_id=? ORDER BY name',(current()['id'],)).fetchall(); c.close(); return render_template('teacher_form.html',schools=schools,quotas=QUOTAS,teacher=None)
  if current()['role']!='admin':
   selected=[int(x) for x in (d.get('original_school_id'), d.get('delegated_school_id')) if x]
   if any(not allowed_school(x) for x in selected): abort(403)
  c=db(); c.execute('''INSERT INTO teachers(name,job_title,appointment_date,official_appointment_date,national_id,birth_date,code,original_school_id,delegated_school_id,classes_count,lessons_count,residence,phone,transferred_activity,stage) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',tuple(d.get(k) or None for k in ['name','job_title','appointment_date','official_appointment_date','national_id','birth_date','code','original_school_id','delegated_school_id','classes_count','lessons_count','residence','phone','transferred_activity','stage'])); tid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close(); audit('إضافة','معلم',tid,d['name']); flash('تمت إضافة المعلم','success'); return redirect(url_for('teachers'))
 c=db(); schools=c.execute('SELECT * FROM schools ORDER BY name').fetchall() if current()['role']=='admin' else c.execute('SELECT * FROM schools WHERE supervisor_id=? ORDER BY name',(current()['id'],)).fetchall(); c.close(); return render_template('teacher_form.html',schools=schools,quotas=QUOTAS,teacher=None)

@app.route('/teacher/<int:tid>/edit',methods=['GET','POST'])
@login_required
def teacher_edit(tid):
 c=db(); t=c.execute('SELECT * FROM teachers WHERE id=?',(tid,)).fetchone()
 if not t: c.close(); abort(404)
 if current()['role']!='admin' and not (allowed_school(t['original_school_id']) or allowed_school(t['delegated_school_id'])): c.close(); abort(403)
 if request.method=='POST':
  d=request.form
  errors=validate_teacher_data(d, tid)
  if errors:
   for e in errors: flash(e,'danger')
   schools=c.execute('SELECT * FROM schools ORDER BY name').fetchall() if current()['role']=='admin' else c.execute('SELECT * FROM schools WHERE supervisor_id=? ORDER BY name',(current()['id'],)).fetchall(); c.close(); return render_template('teacher_form.html',schools=schools,quotas=QUOTAS,teacher=t)
  if current()['role']!='admin':
   selected=[int(x) for x in (d.get('original_school_id'), d.get('delegated_school_id')) if x]
   if any(not allowed_school(x) for x in selected): c.close(); abort(403)
  c.execute('''UPDATE teachers SET name=?,job_title=?,appointment_date=?,official_appointment_date=?,national_id=?,birth_date=?,code=?,original_school_id=?,delegated_school_id=?,classes_count=?,lessons_count=?,residence=?,phone=?,transferred_activity=?,stage=? WHERE id=?''',tuple(d.get(k) or None for k in ['name','job_title','appointment_date','official_appointment_date','national_id','birth_date','code','original_school_id','delegated_school_id','classes_count','lessons_count','residence','phone','transferred_activity','stage'])+(tid,)); c.commit(); c.close(); audit('تعديل','معلم',tid,d['name']); flash('تم تحديث بيانات المعلم','success'); return redirect(url_for('teachers'))
 schools=c.execute('SELECT * FROM schools ORDER BY name').fetchall() if current()['role']=='admin' else c.execute('SELECT * FROM schools WHERE supervisor_id=? ORDER BY name',(current()['id'],)).fetchall(); c.close(); return render_template('teacher_form.html',schools=schools,quotas=QUOTAS,teacher=t)

@app.route('/teacher/<int:tid>/delete',methods=['POST'])
@admin_required
def teacher_delete(tid):
 c=db(); t=c.execute('SELECT name FROM teachers WHERE id=?',(tid,)).fetchone(); c.execute('DELETE FROM teachers WHERE id=?',(tid,)); c.commit(); c.close(); audit('حذف','معلم',tid,t['name'] if t else ''); flash('تم حذف المعلم','success'); return redirect(url_for('teachers'))

@app.route('/school/<int:sid>')
@login_required
def school_detail(sid):
 if not allowed_school(sid): abort(403)
 c=db(); s=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE s.id=?',(sid,)).fetchone()
 if not s: c.close(); abort(404)
 ts=c.execute('SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id WHERE t.delegated_school_id=? OR t.original_school_id=? ORDER BY t.name',(sid,sid)).fetchall(); c.close()
 counts={'KG1':s['kg1'],'KG2':s['kg2'],'ابتدائي1':s['g1'],'ابتدائي2':s['g2'],'ابتدائي3':s['g3'],'ابتدائي4':s['g4'],'ابتدائي5':s['g5'],'ابتدائي6':s['g6'],'إعدادي1':s['p1'],'إعدادي2':s['p2'],'إعدادي3':s['p3'],'ثانوي1':s['s1'],'ثانوي2':s['s2'],'ثانوي3':s['s3']}
 breakdown=[{'grade':k,'classes':int(v or 0),'lesson_rate':LESSONS[k],'required':int(v or 0)*LESSONS[k]} for k,v in counts.items() if int(v or 0)>0]
 st=school_stats(s)
 return render_template('school_detail.html',school=s,teachers=ts,breakdown=breakdown,stats=st,teacher_quota=teacher_quota)

@app.route('/teacher/<int:tid>')
@login_required
def teacher_detail(tid):
 c=db(); t=c.execute('SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id WHERE t.id=?',(tid,)).fetchone(); c.close()
 if not t: abort(404)
 if current()['role']!='admin' and not (allowed_school(t['original_school_id']) or allowed_school(t['delegated_school_id'])): abort(403)
 return render_template('teacher_detail.html',teacher=t,quota=teacher_quota(t))

@app.route('/search')
@login_required
def global_search():
 q=request.args.get('q','').strip(); teachers=[]; schools=[]
 if q:
  c=db(); args=[f'%{q}%']*4
  sql='SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id WHERE (t.name LIKE ? OR t.national_id LIKE ? OR t.code LIKE ? OR t.phone LIKE ?)'
  if current()['role']!='admin': sql+=' AND (os.supervisor_id=? OR ds.supervisor_id=?)'; args += [current()['id'],current()['id']]
  teachers=c.execute(sql,args).fetchall()
  sql2='SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE (s.name LIKE ? OR s.code LIKE ? OR s.address LIKE ?)'; a2=[f'%{q}%']*3
  if current()['role']!='admin': sql2+=' AND s.supervisor_id=?'; a2.append(current()['id'])
  schools=c.execute(sql2,a2).fetchall(); c.close()
 return render_template('search.html',q=q,teachers=teachers,schools=schools,teacher_quota=teacher_quota)

@app.route('/schools')
@login_required
def schools():
 c=db(); rows=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id '+('WHERE s.supervisor_id=? ' if current()['role']!='admin' else '')+'ORDER BY s.name',((current()['id'],) if current()['role']!='admin' else ())).fetchall(); c.close(); return render_template('schools.html',schools=rows,school_stats=school_stats)

@app.route('/school/new',methods=['GET','POST'])
@admin_required
def school_new():
 if request.method=='POST':
  d=request.form; fields=['code','name','stage','supervisor_id','address','status','kg1','kg2','g1','g2','g3','g4','g5','g6','p1','p2','p3','s1','s2','s3']; c=db(); c.execute('INSERT INTO schools('+','.join(fields)+') VALUES('+','.join('?'*len(fields))+')',tuple(d.get(x) or 0 for x in fields)); sid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close(); audit('إضافة','مدرسة',sid,d['name']); flash('تمت إضافة المدرسة','success'); return redirect(url_for('schools'))
 c=db(); supervisors=c.execute("SELECT * FROM users WHERE role='supervisor' AND active=1 ORDER BY name").fetchall(); c.close(); return render_template('school_form.html',school=None,supervisors=supervisors)

@app.route('/school/<int:sid>/edit',methods=['GET','POST'])
@admin_required
def school_edit(sid):
 c=db(); s=c.execute('SELECT * FROM schools WHERE id=?',(sid,)).fetchone()
 if not s: c.close(); abort(404)
 if request.method=='POST':
  d=request.form; fields=['code','name','stage','supervisor_id','address','status','kg1','kg2','g1','g2','g3','g4','g5','g6','p1','p2','p3','s1','s2','s3']; c.execute('UPDATE schools SET '+','.join(f'{x}=?' for x in fields)+' WHERE id=?',tuple(d.get(x) or 0 for x in fields)+(sid,)); c.commit(); c.close(); audit('تعديل','مدرسة',sid,d['name']); flash('تم تحديث المدرسة','success'); return redirect(url_for('schools'))
 supervisors=c.execute("SELECT * FROM users WHERE role='supervisor' AND active=1 ORDER BY name").fetchall(); c.close(); return render_template('school_form.html',school=s,supervisors=supervisors)

@app.route('/school/<int:sid>/delete',methods=['POST'])
@admin_required
def school_delete(sid):
 c=db(); s=c.execute('SELECT name FROM schools WHERE id=?',(sid,)).fetchone()
 if not s:
  c.close(); abort(404)
 linked=c.execute('SELECT COUNT(*) FROM teachers WHERE original_school_id=? OR delegated_school_id=?',(sid,sid)).fetchone()[0]
 if linked:
  c.close(); flash('لا يمكن حذف المدرسة لأنها مرتبطة بمعلمين. قم أولًا بإعادة توزيع/فك ارتباط المعلمين.','warning'); return redirect(url_for('schools'))
 c.execute('DELETE FROM routes WHERE school_id=?',(sid,)); c.execute('DELETE FROM schools WHERE id=?',(sid,)); c.commit(); c.close(); audit('حذف','مدرسة',sid,s['name']); flash('تم حذف المدرسة','success'); return redirect(url_for('schools'))

@app.route('/users')
@admin_required
def users():
 c=db(); rows=c.execute('SELECT * FROM users ORDER BY role,name').fetchall(); c.close(); return render_template('users.html',users=rows)
@app.route('/user/new',methods=['GET','POST'])
@admin_required
def user_new():
 if request.method=='POST':
  d=request.form; c=db(); c.execute('INSERT INTO users(name,username,password,role,phone,active) VALUES(?,?,?,?,?,1)',(d['name'],d['username'],generate_password_hash(d['password']),d['role'],d.get('phone'))); uid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close(); audit('إضافة','مستخدم',uid,d['name']); flash('تم إنشاء المستخدم','success'); return redirect(url_for('users'))
 return render_template('user_form.html',user=None)
@app.route('/user/<int:uid>/toggle',methods=['POST'])
@admin_required
def user_toggle(uid):
 if uid==current()['id']: flash('لا يمكن تعطيل الحساب الحالي','warning'); return redirect(url_for('users'))
 c=db(); c.execute('UPDATE users SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?',(uid,)); c.commit(); c.close(); audit('تغيير حالة','مستخدم',uid); return redirect(url_for('users'))

@app.route('/routes')
@login_required
def routes():
 c=db();
 if current()['role']=='admin': rows=c.execute('SELECT r.*,u.name supervisor_name,s.name school_name FROM routes r JOIN users u ON u.id=r.supervisor_id JOIN schools s ON s.id=r.school_id ORDER BY u.name,r.day,r.visit_order').fetchall()
 else: rows=c.execute('SELECT r.*,u.name supervisor_name,s.name school_name FROM routes r JOIN users u ON u.id=r.supervisor_id JOIN schools s ON s.id=r.school_id WHERE r.supervisor_id=? ORDER BY r.day,r.visit_order',(current()['id'],)).fetchall()
 c.close(); return render_template('routes.html',routes=rows)
@app.route('/route/new',methods=['GET','POST'])
@admin_required
def route_new():
 c=db()
 if request.method=='POST':
  d=request.form
  supervisor_id=int(d.get('supervisor_id') or 0); school_id=int(d.get('school_id') or 0)
  ok=c.execute("SELECT 1 FROM users WHERE id=? AND role='supervisor' AND active=1",(supervisor_id,)).fetchone()
  assigned=c.execute('SELECT 1 FROM schools WHERE id=? AND supervisor_id=?',(school_id,supervisor_id)).fetchone()
  if not ok or not assigned:
   c.close(); flash('لا يمكن إنشاء خط سير لمدرسة غير مسندة إلى هذا الموجه.','danger')
  else:
   c.execute('INSERT INTO routes(supervisor_id,day,school_id,visit_order,visit_time,notes) VALUES(?,?,?,?,?,?)',(supervisor_id,d['day'],school_id,d.get('visit_order') or 1,d.get('visit_time'),d.get('notes'))); rid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close(); audit('إضافة','خط سير',rid); flash('تمت إضافة الزيارة','success'); return redirect(url_for('routes'))
 su=c.execute("SELECT * FROM users WHERE role='supervisor' AND active=1 ORDER BY name").fetchall(); sc=c.execute('SELECT * FROM schools ORDER BY name').fetchall(); c.close(); return render_template('route_form.html',supervisors=su,schools=sc)


@app.route('/allocations')
@login_required
def allocations():
 c=db()
 if current()['role']=='admin':
  schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id ORDER BY s.name').fetchall()
 else:
  schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE s.supervisor_id=? ORDER BY s.name',(current()['id'],)).fetchall()
 data=[]
 for s in schools:
  ts=c.execute('SELECT * FROM teachers WHERE delegated_school_id=? OR original_school_id=? ORDER BY name',(s['id'],s['id'])).fetchall()
  capacity=sum(teacher_quota(t) for t in ts)
  req=required_lessons(s)
  # transparent distribution: allocate available capacity in listed teacher order against school demand
  remaining=req; rows=[]
  for t in ts:
   q=teacher_quota(t); assigned=min(q,max(remaining,0)); remaining=max(0,remaining-assigned)
   rows.append({'teacher':t,'quota':q,'assigned':assigned,'unused':max(0,q-assigned)})
  data.append({'school':s,'required':req,'capacity':capacity,'shortage':max(0,req-capacity),'surplus':max(0,capacity-req),'rows':rows})
 c.close(); return render_template('allocations.html',data=data)

@app.route('/reports')
@login_required
def reports():
 c=db()
 if current()['role']=='admin':
  schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id ORDER BY s.name').fetchall()
 else:
  schools=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE s.supervisor_id=? ORDER BY s.name',(current()['id'],)).fetchall()
 summary=[]
 for s in schools:
  x=school_stats(s); summary.append({'school':s,'stats':x})
 totals={k:sum(x['stats'][k] for x in summary) for k in ['required','available','shortage','surplus','teachers']}
 c.close(); return render_template('reports.html',summary=summary,totals=totals)

@app.route('/reports/schools.csv')
@login_required
def report_schools():
 c=db()
 if current()['role']=='admin': rows=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id ORDER BY s.name').fetchall()
 else: rows=c.execute('SELECT s.*,u.name supervisor_name FROM schools s LEFT JOIN users u ON u.id=s.supervisor_id WHERE s.supervisor_id=? ORDER BY s.name',(current()['id'],)).fetchall()
 c.close(); out=io.StringIO(); w=csv.writer(out); w.writerow(['كود المدرسة','اسم المدرسة','المرحلة','الموجه','إجمالي الحصص المطلوبة','الحصص المتاحة','العجز','الزيادة','عدد المعلمين'])
 for s in rows:
  x=school_stats(s); w.writerow([s['code'] or '',s['name'],s['stage'],s['supervisor_name'] or '',x['required'],x['available'],x['shortage'],x['surplus'],x['teachers']])
 return Response('\ufeff'+out.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=schools_report.csv'})

@app.route('/reports/teachers.csv')
@login_required
def report_teachers():
 c=db();
 if current()['role']=='admin': rows=c.execute('SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id ORDER BY t.name').fetchall()
 else: rows=c.execute('SELECT t.*,os.name original_name,ds.name delegated_name FROM teachers t LEFT JOIN schools os ON os.id=t.original_school_id LEFT JOIN schools ds ON ds.id=t.delegated_school_id WHERE os.supervisor_id=? OR ds.supervisor_id=? ORDER BY t.name',(current()['id'],current()['id'])).fetchall()
 c.close(); out=io.StringIO(); w=csv.writer(out); w.writerow(['اسم المعلم','المسمى الوظيفي','المرحلة','الكود','الرقم القومي','المدرسة الأصلية','المدرسة المنتدب إليها','النصاب الأسبوعي','الحصص المسجلة','الهاتف'])
 for t in rows: w.writerow([t['name'],t['job_title'],t['stage'],t['code'] or '',t['national_id'] or '',t['original_name'] or '',t['delegated_name'] or '',teacher_quota(t),t['lessons_count'] or 0,t['phone'] or ''])
 return Response('\ufeff'+out.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=teachers_report.csv'})


@app.route('/account/password', methods=['GET','POST'])
@login_required
def change_password():
    if request.method=='POST':
        d=request.form
        c=db(); u=c.execute('SELECT password FROM users WHERE id=?',(current()['id'],)).fetchone()
        if not u or not check_password_hash(u['password'], d.get('current_password','')):
            c.close(); flash('كلمة المرور الحالية غير صحيحة.','danger'); return render_template('password_change.html')
        new=d.get('new_password','')
        if len(new)<10 or new==d.get('current_password',''):
            c.close(); flash('كلمة المرور الجديدة يجب أن تكون 10 أحرف/أرقام على الأقل وألا تكون نفس القديمة.','danger'); return render_template('password_change.html')
        if new != d.get('confirm_password',''):
            c.close(); flash('تأكيد كلمة المرور غير مطابق.','danger'); return render_template('password_change.html')
        c.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(new),current()['id'])); c.commit(); c.close(); audit('تغيير كلمة المرور','مستخدم',current()['id']); flash('تم تغيير كلمة المرور بنجاح.','success'); return redirect(url_for('dashboard'))
    return render_template('password_change.html')

@app.route('/admin/backup')
@admin_required
def backup_database():
    if not DB.exists(): abort(404)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    audit('نسخة احتياطية','قاعدة البيانات',None,stamp)
    # Re-open after the audit so the downloaded copy includes the audit entry.
    data=DB.read_bytes()
    return Response(data, mimetype='application/octet-stream', headers={'Content-Disposition':f'attachment; filename=english_supervision_backup_{stamp}.db'})

@app.route('/audit')
@admin_required
def audit_page():
 c=db(); rows=c.execute('SELECT a.*,u.name user_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 300').fetchall(); c.close(); return render_template('audit.html',logs=rows)

if __name__=='__main__':
    init_db()
    app.run(host=os.environ.get('HOST','127.0.0.1'), port=int(os.environ.get('PORT','5000')), debug=os.environ.get('FLASK_DEBUG','0')=='1')
