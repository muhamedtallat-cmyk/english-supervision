import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app.py'
TREE = ast.parse(APP.read_text(encoding='utf-8'))


def literal(name):
    for node in TREE.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError(f'{name} not found')

QUOTAS = literal('QUOTAS')
LESSONS = literal('LESSONS')


def required_lessons(counts):
    return sum(int(counts.get(k, 0) or 0) * rate for k, rate in LESSONS.items())


def quota(stage, job):
    return QUOTAS[stage][job]


def test_primary_lesson_rates():
    assert [LESSONS[f'ابتدائي{i}'] for i in range(1, 7)] == [5, 5, 5, 4, 4, 4]


def test_preparatory_lesson_rates():
    assert [LESSONS[f'إعدادي{i}'] for i in range(1, 4)] == [5, 6, 6]


def test_secondary_lesson_rates():
    assert [LESSONS[f'ثانوي{i}'] for i in range(1, 4)] == [4, 6, 6]


def test_primary_quota_rules():
    assert quota('ابتدائي', 'معلم مساعد') == 24
    assert quota('ابتدائي', 'معلم أول أ') == 20
    assert quota('ابتدائي', 'كبير معلمين') == 16


def test_preparatory_and_secondary_quota_rules():
    assert quota('إعدادي', 'معلم') == 21
    assert quota('إعدادي', 'معلم خبير') == 17
    assert quota('ثانوي', 'معلم أول') == 17
    assert quota('ثانوي', 'كبير معلمين') == 14


def test_required_lessons_calculation():
    counts = {'ابتدائي1': 2, 'ابتدائي4': 3, 'ابتدائي6': 1}
    assert required_lessons(counts) == (2 * 5) + (3 * 4) + (1 * 4)


def test_capacity_and_shortage_math():
    capacity = quota('ابتدائي', 'معلم') + quota('ابتدائي', 'معلم أول')
    required = 50
    assert capacity == 46
    assert max(0, required - capacity) == 4
    assert max(0, capacity - required) == 0


def test_security_regressions():
    source = APP.read_text(encoding='utf-8')
    assert "errors=validate_teacher_data(d, None)" in source
    assert "errors=validate_teacher_data(d, tid)" in source
    assert "@app.before_request" in source and "csrf_protect" in source
    assert "secrets.compare_digest" in source
    assert "@admin_required" in source
    assert "assigned=c.execute('SELECT 1 FROM schools WHERE id=? AND supervisor_id=?'" in source


if __name__ == '__main__':
    for name in sorted(globals()):
        if name.startswith('test_'):
            globals()[name]()
    print('All business-rule tests passed.')
